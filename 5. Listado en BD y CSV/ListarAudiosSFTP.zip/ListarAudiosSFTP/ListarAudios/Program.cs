﻿using System;
using System.IO;
using System.Net;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using WinSCP;
using static System.Collections.Specialized.BitVector32;
using EnumerationOptions = WinSCP.EnumerationOptions;

namespace ListarAudios
{
    class Progam
    {
        private static string lOG_PATH = "C:\\Windows\\SysWOW64\\config\\systemprofile\\inConcert\\Logs\\ListarAudios.log";
        public static string LOG_PATH { get => lOG_PATH; set => lOG_PATH = value; }

        static void Main(string[] args)
        {
            IConfiguration Config = new ConfigurationBuilder()
                .AddJsonFile("appSettings.json")
                .Build();

            //Defino credenciales de conexion y rutas del SFTP
            string sftpHost = Config.GetSection("sftpHost").Value;
            string sftpPath = Config.GetSection("sftpPath").Value;
            string sftpUsername = Config.GetSection("sftpUsername").Value;
            string sftpFingerPrint = Config.GetSection("sftpFingerPrint").Value;
            string sftpPassword = Config.GetSection("sftpPassword").Value;
            string sftpArchivoLista = Config.GetSection("sftpArchivoLista").Value;
            string rutaCSV = Config.GetSection("rutaArchivoCSV").Value;
            string spBulk = Config.GetSection("spBulk").Value;
            string timeouttext = Config.GetSection("timeout_win").Value;
            int timeout_win = int.Parse(timeouttext);
            string diaListarString = Config.GetSection("diaListar").Value;
            int diaListar = int.Parse(diaListarString);

            //Defino credenciales de la base de datos
            string dataSource = Config.GetSection("dataSource").Value;

            //Defino ruta y cabecera del archivo a generar
            string rutaArchivo = @rutaCSV;
            string cabecera = Config.GetSection("cabecera").Value;

            //Obtengo el dia de ayer
            DateTime utcDate = DateTime.UtcNow;
            DateTime fechaAyer = utcDate.AddDays(-1 * diaListar);

            //Defino la ruta de los archivos a listar
            string rutafecha = fechaAyer.Year.ToString() + "/" + fechaAyer.Month.ToString() + "/" + fechaAyer.Day.ToString() + "/";
            string ruta = sftpPath + rutafecha;
            string fechaCreacion = fechaAyer.Year.ToString() + "-" + fechaAyer.Month.ToString() + "-" + fechaAyer.Day.ToString();

            //Defino nombre de acuerdo a la fecha (sirve para la carga del archivo al SFTP)
            string nombreArchivo = fechaAyer.Year.ToString() + "_" + fechaAyer.Month.ToString() + "_" + fechaAyer.Day.ToString() + "_WAV_Audios.csv";

            //Logs
            string fechayhora = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
            LoggingExtensions.WriteDebug(LOG_PATH, fechayhora + " ::Inicia proceso de listado de archivos");
            LoggingExtensions.WriteDebug(LOG_PATH, fechayhora + " ::Path de Carpeta :: " + ruta);

            //Obtengo todos los archivos del directorio
            List<string> filesList = GetFilesList(sftpHost, sftpUsername, sftpPassword, sftpFingerPrint, ruta, cabecera, fechaCreacion, timeout_win);

            //Creo el archivo CSV con solo el nombre, la ruta y la fecha correspondiente
            try
            {
                File.WriteAllLines(rutaArchivo, filesList);
                string fechayhora_2 = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
                LoggingExtensions.WriteDebug(LOG_PATH, fechayhora_2 + " :: Escritura exitosa de CSV");
            }
            catch (Exception ex)
            {
                //Logs
                string fechayhora_3 = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
                LoggingExtensions.WriteDebug(LOG_PATH, fechayhora_3 + " :: ERROR :: Escritura de CSV" + ex);
                throw ex;
            }
            

            //Ejecuto el store procedure que lee el archivo generado para subirlo a una BD
            try
            {
                SqlConnection con = null;
                con = new SqlConnection(dataSource);
                SqlCommand cmd = new SqlCommand(spBulk, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                string fechayhora_4 = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
                LoggingExtensions.WriteDebug(LOG_PATH, fechayhora_4 + " :: Cargado exitoso de lista a BD");
            }
            catch (Exception ex)
            {
                //Logs
                string fechayhora_5 = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
                LoggingExtensions.WriteDebug(LOG_PATH, fechayhora_5 + " :: ERROR :: Cargado de lista a BD" + ex);
                throw ex;
            }

            //Envio el archivo CSV al SFTP
            UploadFile(sftpHost, nombreArchivo, sftpUsername, sftpPassword, sftpFingerPrint,sftpArchivoLista, timeout_win, @rutaCSV);

            //Logs
            string fechayhora_6 = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
            LoggingExtensions.WriteDebug(LOG_PATH, fechayhora_6 + " :: Ejecucion exitosa");

        }

        public static List<string> GetFilesList(string sftpHost, string sftpUsername, string sftpPassword, string sftpFingerPrint, string ruta, string cabecera, string fecha, int timeout)
        {
            try
            {
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = sftpHost,
                    UserName = sftpUsername,
                    Password = sftpPassword,
                    SshHostKeyFingerprint = sftpFingerPrint,
                    Timeout = TimeSpan.FromMinutes(timeout)
                };

                using (Session session = new Session())
                {
                    List<string> filesList = new List<string>();
                    filesList.Add(cabecera);

                    session.Open(sessionOptions);

                    IEnumerable<RemoteFileInfo> fileInfos = session.EnumerateRemoteFiles(ruta, "*", EnumerationOptions.AllDirectories);
                    foreach (RemoteFileInfo fileInfo in fileInfos)
                    {
                        filesList.Add(fileInfo.Name + ";" + ruta + fileInfo.Name + ";" + fecha);
                    }

                    //Logs
                    string fechayhora = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
                    LoggingExtensions.WriteDebug(LOG_PATH, fechayhora + " :: Obtencion exitosa listado de archivos");

                    return filesList;
                }
            }
            catch (Exception ex)
            {
                //Logs
                string fechayhora = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
                LoggingExtensions.WriteDebug(LOG_PATH, fechayhora + " :: ERROR Obtencion listado de archivos:: " + ex);
                throw ex;
            }

            
        }

        public static void UploadFile(string sftpHost, string fileName, string sftpUsername, string sftpPassword, string sftpFingerPrint, string filePath, int timeout,string rutaCSVcarga)
        {
            try
            {
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = sftpHost,
                    UserName = sftpUsername,
                    Password = sftpPassword,
                    SshHostKeyFingerprint = sftpFingerPrint,
                    Timeout = TimeSpan.FromMinutes(timeout)
                };

                using (Session session = new Session())
                {

                    session.Open(sessionOptions);

                    // Upload files
                    TransferOptions transferOptions = new TransferOptions();
                    transferOptions.TransferMode = TransferMode.Binary;

                    TransferOperationResult transferResult;
                    transferResult =
                        session.PutFiles(rutaCSVcarga, filePath + fileName, false, transferOptions);

                    // Throw on any error
                    transferResult.Check();

                    //Logs
                    string fechayhora = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
                    LoggingExtensions.WriteDebug(LOG_PATH, fechayhora + " :: Termino exitoso de carga de listado a SFTP");
                }
                
            }
            catch (Exception ex)
            {
                //Logs
                string fechayhora = DateTime.UtcNow.AddHours(-5).ToString("yyyy") + "-" + DateTime.UtcNow.AddHours(-5).ToString("MM") + "-" + DateTime.UtcNow.AddHours(-5).ToString("dd") + " " + DateTime.UtcNow.AddHours(-5).ToString("hh:mm:ss");
                LoggingExtensions.WriteDebug(LOG_PATH, fechayhora + " :: ERROR Carga Listado a SFTP:: " + ex);
                throw ex;
            }
        }
    }
}



