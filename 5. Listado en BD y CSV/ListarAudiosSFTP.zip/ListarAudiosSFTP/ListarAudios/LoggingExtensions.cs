﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ListarAudios
{
    public static class LoggingExtensions
    {
        static ReaderWriterLock locker = new ReaderWriterLock();
        public static void WriteDebug(string path, string text)
        {
            try
            {
                locker.AcquireWriterLock(int.MaxValue);
                System.IO.File.AppendAllLines(@path, new[] { text });
            }
            catch (Exception)
            {
                Thread.Sleep(500);
                locker.AcquireWriterLock(int.MaxValue);
                System.IO.File.AppendAllLines(@path, new[] { text });
            }
            finally
            {
                locker.ReleaseWriterLock();
            }
        }
    }
}
